-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ipms_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `user_type` enum('INVENTOR','CONSULTANT','ADMIN') NOT NULL,
  `profile_picture` varchar(500) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` text,
  `age` int DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `verification_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expiry` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `approval_status` varchar(20) DEFAULT 'pending' COMMENT 'Approval status: pending, approved, rejected',
  `rejection_reason` text,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_verification_token` (`verification_token`),
  KEY `idx_contact` (`contact`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'macalannamaica@gmail.com','$2b$12$AKojI3jM6KlBYwSgXZvmgehQZP2AeHDgcDDQtG2HaaxwdCTdcdvaG','CONSULTANT',NULL,'Anna Maica Bibon Macal',NULL,'Purok 6 Tumbaga SanRafael Jose Panganiban Camarines Norte',24,'2003-03-24',0,'3d8be79a-3a2d-40ad-ac21-884ed947e697',NULL,NULL,'2025-12-27 04:12:56','2026-01-04 18:18:58','2026-01-04 18:18:58',1,NULL,NULL,NULL,NULL),(2,'macalkenmatthew28@gmail.com','$2b$12$T0o/ba3bqM9G.lzkFOoaV.DZQ.ZNAFG4GO1Ot5MTY1XLXaoIW8UJi','INVENTOR',NULL,'Anna Maica Bibon Macal',NULL,'Jose Panganiban Camarines Norte',21,'2004-03-24',1,NULL,NULL,NULL,'2025-12-27 15:22:25','2026-01-20 15:51:48','2026-01-06 01:27:08',1,'approved',NULL,NULL,NULL),(3,'ernel@gmail.com','$2b$12$GJZ.ewCrOMUfrATzWkCsOOYch0VGOXu9C9U0P5lsla96Fn72GaTiW','CONSULTANT','profile-1767370698195-752439019.jpg','Ernelita D. Tormes',NULL,'Paracale Camarines Norte',28,'1998-01-03',1,NULL,NULL,NULL,'2026-01-02 16:18:20','2026-01-05 16:41:13','2026-01-05 16:41:13',1,NULL,NULL,NULL,NULL),(6,'rada@gmail.com','$2b$12$nNm2J3Ieg7nnyv42CWSbP.vWo/51tIybyqxMe8a5Cd53Hsz4bqQxq','ADMIN','profile-1767756153911-309776612.jpg','Mark Reniel Rada',NULL,'n/a',21,'2004-10-10',1,NULL,NULL,NULL,'2026-01-07 03:22:35','2026-01-24 11:04:20','2026-01-24 11:04:20',1,'approved',NULL,NULL,NULL),(7,'macalanna@gmail.com','$2b$12$OjNDdl8Xn51zM5Su5PDSC.MLKxQD9oKv0nNRz8BJ.yxTETvf50vsa','INVENTOR','profile-1767844030650-609770219.jpg','Anna Maica Bibon Macal',NULL,'SAMPLE ADDRESS',21,'2004-03-24',1,NULL,NULL,NULL,'2026-01-08 03:47:13','2026-01-24 01:42:10','2026-01-24 01:42:10',1,'approved',NULL,'2026-01-08 04:19:18',6),(8,'andrew@gmail.com','$2b$12$wJunqT0Yu/lF2iFfPGZ8Be9Jqxj2eZ2bpAR9hMMh5cpv6i3/dd1Mu','CONSULTANT','profile-1767985746317-791043855.jpg','Andrew Lee ',NULL,'Purok 3 SantaRosa Norte Jose Panganiban Camarines Norte',25,'1999-08-12',1,NULL,NULL,NULL,'2026-01-09 19:09:18','2026-01-22 16:46:13','2026-01-22 16:46:13',1,'approved',NULL,'2026-01-09 19:09:57',6),(9,'john@gmail.com','$2b$12$.Zy0W3QsfdKIa0JB4b6ocePOATIl15tDUuqgwRDd3UIqO1DH19xSS','INVENTOR','profile-1768113925363-161194936.jpg','John Clerk Rafael',NULL,'Labo Camarines Norte',22,'2004-01-02',1,NULL,NULL,NULL,'2026-01-11 06:45:26','2026-01-13 08:18:11',NULL,1,'approved',NULL,'2026-01-13 08:18:11',6),(10,'ken@gmail.com','$2b$12$uZox8EneoP5KMIZVWbBHne2JQlujK9M4EJn7QxRPD09McEWINk3Pu','INVENTOR','profile-1768280645636-375539889.jpg','Ken Matthew Bibon Macal',NULL,'hdgh',20,'2002-10-10',1,NULL,NULL,NULL,'2026-01-13 05:04:07','2026-01-13 05:06:16','2026-01-13 05:06:16',1,'approved',NULL,'2026-01-13 05:05:31',6),(11,'arolfvegz@gmail.com','$2b$12$mwFt80lCtuFnWFyqkB3xWOkCIHCTs0jJcDXZnapCGY6WtJPNScX0q','INVENTOR',NULL,'Flor Vega',NULL,'daet',24,'2001-05-09',1,NULL,NULL,NULL,'2026-01-14 01:39:51','2026-01-14 01:42:28','2026-01-14 01:42:28',1,'approved',NULL,'2026-01-14 01:40:34',6),(12,'daniel@gmail.com','$2b$12$brGHS5SFkoq9WpCCJu6xv.pKHfo5vHrhyLOEAt0.oU26uiDfvg5h.','INVENTOR','profile-1769225547700-549181976.jpg','Daniel Zabala','09070073875','San Rafael\r\nTumbaga',22,'2003-05-21',1,NULL,NULL,NULL,'2026-01-24 03:32:35','2026-01-24 04:02:22',NULL,1,'approved',NULL,'2026-01-24 04:02:22',6);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-24 19:38:09
