-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ipms_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `submission_status_history`
--

DROP TABLE IF EXISTS `submission_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submission_prefix` varchar(10) NOT NULL,
  `submission_id` int NOT NULL,
  `stage` varchar(255) NOT NULL,
  `status_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `completed` tinyint(1) DEFAULT '0',
  `note` text,
  PRIMARY KEY (`id`),
  KEY `submission_prefix` (`submission_prefix`,`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_status_history`
--

LOCK TABLES `submission_status_history` WRITE;
/*!40000 ALTER TABLE `submission_status_history` DISABLE KEYS */;
INSERT INTO `submission_status_history` VALUES (49,'um',11,'New Submission','2026-01-13 12:58:50',1,'Initial submission'),(50,'um',12,'New Submission','2026-01-13 13:00:16',1,'Initial submission'),(51,'id',22,'New Submission','2026-01-13 13:54:47',1,'Initial submission'),(52,'id',22,'Under Review','2026-01-13 13:56:00',0,'Received by admin for triage'),(53,'id',22,'Ready for Review','2026-01-13 13:57:11',1,'Ready to Approved project'),(54,'id',22,'Approved for Filing','2026-01-13 13:57:31',1,'Ready to Approved project'),(55,'um',13,'New Submission','2026-01-13 16:06:15',1,'Initial submission'),(56,'id',23,'New Submission','2026-01-13 16:09:55',1,'Initial submission'),(57,'id',23,'Under Review','2026-01-14 03:27:14',0,'Received by admin for triage'),(58,'um',14,'New Submission','2026-01-14 09:53:55',1,'Initial submission'),(59,'um',14,'Under Review','2026-01-14 09:56:15',0,'Received by admin for triage'),(60,'um',14,'Approved for Filing','2026-01-14 09:58:35',1,'Status changed to Approved for Filing'),(61,'um',13,'Under Review','2026-01-14 10:18:32',0,'Received by admin for triage'),(62,'um',12,'Under Review','2026-01-14 10:22:44',0,'Received by admin for triage'),(63,'um',11,'Under Review','2026-01-14 10:23:06',0,'Received by admin for triage'),(64,'id',23,'Under Review','2026-01-14 10:29:46',0,'unspecified pictureefd ffsf '),(65,'id',23,'Rejected','2026-01-14 10:30:05',0,'unspecified pictureefd ffsf '),(66,'um',13,'Under Review','2026-01-16 02:07:12',0,'You have a missing part of your submission'),(67,'um',13,'Approved for Filing','2026-01-20 12:47:01',1,'You have a missing part of your submission'),(68,'um',12,'Under Review','2026-01-20 16:44:18',0,'Visual is not clear'),(69,'um',12,'Rejected','2026-01-20 16:45:02',0,'Visual is not clear'),(70,'um',15,'New Submission','2026-01-22 21:39:39',1,'Initial submission'),(71,'um',15,'Under Review','2026-01-22 21:46:52',0,'Received by admin for triage'),(72,'um',15,'Approved for Filing','2026-01-22 21:57:38',1,'Status changed to Approved for Filing');
/*!40000 ALTER TABLE `submission_status_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-24 19:38:06
