-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ipms_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_type` enum('INVENTOR','CONSULTANT','ADMIN') DEFAULT NULL,
  `action_type` enum('Login','Logout','Failed Login','Upload','File Update','File Delete','Feedback','Submission','New Submission','Review','Project Access','Feedback Posted','Approval','Rejection','Status Change','Profile Update','User Registration','Password Reset','Email Change','System Error','Data Export') NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `metadata` json DEFAULT NULL,
  `submission_id` int DEFAULT NULL,
  `project_id` varchar(50) DEFAULT NULL,
  `project_title` varchar(255) DEFAULT NULL,
  `ip_category` varchar(50) DEFAULT NULL,
  `activity_status` enum('SUCCESS','FAILED','ERROR','WARNING') DEFAULT 'SUCCESS',
  `old_value` text,
  `new_value` text,
  `file_name` varchar(255) DEFAULT NULL,
  `flag_type` enum('NORMAL','ERROR','WARNING','CRITICAL') DEFAULT 'NORMAL',
  `submission_type` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action_type` (`action_type`),
  KEY `idx_timestamp` (`timestamp` DESC),
  KEY `idx_submission` (`submission_id`,`submission_type`),
  KEY `idx_project_id` (`project_id`),
  KEY `idx_ip_category` (`ip_category`),
  KEY `idx_activity_status` (`activity_status`),
  KEY `idx_flag_type` (`flag_type`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-21T11:36:47.922Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-21 11:36:47'),(2,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-21T12:08:38.224Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-21 12:08:38'),(3,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-21T12:14:39.737Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-21 12:14:39'),(4,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-21T12:15:08.814Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-21 12:15:08'),(5,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-22T13:10:05.288Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:10:05'),(6,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-22T13:19:20.830Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:19:20'),(7,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-22T13:25:53.090Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:25:53'),(8,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-22T13:44:52.069Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:44:52'),(9,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-22T13:46:44.671Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:46:44'),(10,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-22T13:55:06.199Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 13:55:06'),(11,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-22T15:27:47.740Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 15:27:47'),(12,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-22T16:46:13.297Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 16:46:13'),(13,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-22T16:47:17.561Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-22 16:47:17'),(14,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-24T01:42:10.691Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-24 01:42:10'),(15,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-24T02:25:44.339Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-24 02:25:44'),(16,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-24T03:32:47.827Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-24 03:32:47'),(17,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-24T11:04:20.657Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-24 11:04:20'),(18,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-25T05:34:27.134Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 05:34:27'),(19,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-25T05:51:43.386Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 05:51:43'),(20,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-25T06:42:55.966Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 06:42:55'),(21,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-25T06:59:12.260Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 06:59:12'),(22,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-25T12:34:17.127Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 12:34:17'),(23,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-25T12:38:55.864Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 12:38:55'),(24,7,'Anna Maica Bibon Macal','INVENTOR','Login','Anna Maica Bibon Macal logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"INVENTOR\", \"loginTime\": \"2026-01-25T13:26:47.307Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 13:26:47'),(25,6,'Mark Reniel Rada','ADMIN','Login','Mark Reniel Rada logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"ADMIN\", \"loginTime\": \"2026-01-25T13:35:23.021Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 13:35:23'),(26,8,'Andrew Lee ','CONSULTANT','Login','Andrew Lee  logged in successfully','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','{\"userType\": \"CONSULTANT\", \"loginTime\": \"2026-01-25T13:36:51.833Z\"}',NULL,NULL,NULL,NULL,'SUCCESS',NULL,NULL,NULL,'NORMAL',NULL,'2026-01-25 13:36:51');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-25 23:12:40
