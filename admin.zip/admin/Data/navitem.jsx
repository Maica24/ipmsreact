const navList = [
    {
        _id: 1,
        name: 'Dashboard',
        icon: 'bi bi-person',
    },

];
export default navList;