
const navList = [
    {
        _id: 1,
        name: 'Profile',
        icon: 'bi bi-person',
    },
    {
        _id: 2,
        name: 'Contacts',
        icon: 'bi bi-envelope',
    },
    {
        _id: 3,
        name: 'FAQS',
        icon: 'bi bi-question-circle',
    },
];
export default navList;